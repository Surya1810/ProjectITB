@extends('layouts.app')

@section('title')
    | Court Detail
@endsection

@push('css')
    <style>
        .btn {
            position: fixed;
            bottom: 50px;
            right: 20px;
        }
    </style>
@endpush

@section('content')
    <div class="content-header">
        <div class="container">
            {{-- <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Our Main Feature</h1>
                </div>
            </div> --}}
        </div>
    </div>

    <!-- Main content -->
    <div class="content">
        <div class="container">
            <div class="col-12">
                <form action="{{ route('booking.store') }}" method="POST">
                    @csrf
                    <img src="{{ asset('assets/img/dummy.png') }}" alt="Coord" style="width: 100%;max-height: 50vh">
                    {{-- <div id="map" style="width: 100%;max-height: 50vh"></div> --}}
                    <h2 class="mt-3">{{ $data->court_name }}</h2>
                    <p>{{ $data->location }}</p>

                    <h4 class="font-weight-bolder">{{ $data->price }} / hour</h4>
                    <button type="submit" class="btn btn-success mb-3 px-4">Book</button>
                </form>
            </div>
        </div>
    </div>
@endsection

@push('scripts')
    <script type="text/javascript">
        function showMap() {
            var coord = -6.886045146332705,
                107.63386745108696;

            new google.maps.Map(
                document.getElementById("map"), {
                    zoom: 10,
                    center: coord
                }
            );
        }
    </script>
@endpush
