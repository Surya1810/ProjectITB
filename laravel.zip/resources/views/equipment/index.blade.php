@extends('layouts.app')

@section('title')
    | Home
@endsection

@push('css')
    <style>
        #mybutton {
            position: fixed;
            bottom: 50px;
            right: 10px;
        }
    </style>
@endpush

@section('content')
    <div class="content-header">
        {{-- <div class="container">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Our Main Feature</h1>
                </div>
            </div>
        </div> --}}
    </div>

    <!-- Main content -->
    <div class="content">
        <div class="container">
            <div class="col-sm-12">
                <div class="row">
                    @foreach ($equipment as $data)
                        <div class="col-md-4 col-s-6 col-lg-2 col-12 my-3">
                            <div class="card" style="border-radius: 20px">
                                <img class="card-img-top" src="{{ asset('assets/img/equipment/' . $data->image) }}"
                                    style="border-radius: 20px; height: 300px" alt="Card image cap">
                                <div class="card-body">
                                    <span>{{ $data->item }}</span>
                                    <h5><strong>{{ $data->price }} / Use</strong></h5>
                                </div>
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>
        </div>
    </div>
    <div id="mybutton">
        <button class="btn btn-danger py-2 mb-2"><i class="fa-solid fa-cart-shopping"></i> Checkout</button>
    </div>
@endsection

@push('scripts')
@endpush
