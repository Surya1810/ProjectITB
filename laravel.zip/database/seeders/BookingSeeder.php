<?php

namespace Database\Seeders;

use App\Models\Booking;
use Illuminate\Database\Seeder;

class BookingSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //SARAGA
        $eqt = Booking::create([
            'court_name' => 'Saraga',
            'location' => 'Jl. Siliwangi Dalam 3, Lb. Siliwangi, Kecamatan Coblong, Kota Bandung, Jawa Barat 40132',
            'buka' => '06.00',
            'tutup' => '21.00',
            'category' => 'basketball',
            'price' => '50.000',
        ]);
        $eqt = Booking::create([
            'court_name' => 'Saraga',
            'location' => 'Jl. Siliwangi Dalam 3, Lb. Siliwangi, Kecamatan Coblong, Kota Bandung, Jawa Barat 40132',
            'buka' => '06.00',
            'tutup' => '21.00',
            'category' => 'futsal',
            'price' => '50.000',
        ]);
        $eqt = Booking::create([
            'court_name' => 'Saraga',
            'location' => 'Jl. Siliwangi Dalam 3, Lb. Siliwangi, Kecamatan Coblong, Kota Bandung, Jawa Barat 40132',
            'buka' => '06.00',
            'tutup' => '21.00',
            'category' => 'tennis',
            'price' => '50.000',
        ]);

        //Padjajaran
        $eqt = Booking::create([
            'court_name' => 'GOR Pajajaran',
            'location' => 'Babakan Ciamis, Kec. Sumur Bandung, Kota Bandung, Jawa Barat 40171',
            'buka' => '08.00',
            'tutup' => '18.00',
            'category' => 'basketball',
            'price' => '50.000',
        ]);
        //bikasoga
        $eqt = Booking::create([
            'court_name' => 'GOR Bikasoga',
            'location' => 'Jl. Suryalaya Indah No.1-3, Cijagra, Kec. Lengkong, Kota Bandung, Jawa Barat 40265',
            'buka' => '07.00',
            'tutup' => '22.00',
            'category' => 'tennis',
            'price' => '50.000',
        ]);
        $eqt = Booking::create([
            'court_name' => 'GOR Bikasoga',
            'location' => 'Jl. Suryalaya Indah No.1-3, Cijagra, Kec. Lengkong, Kota Bandung, Jawa Barat 40265',
            'buka' => '07.00',
            'tutup' => '22.00',
            'category' => 'futsal',
            'price' => '50.000',
        ]);

        //The Groove
        $eqt = Booking::create([
            'court_name' => "d'Groove Sport and Wellness Center",
            'location' => 'Jl. Soekarno Hatta No.27, Cibuntu, Kec. Bandung Kulon, Kota Bandung, Jawa Barat 40212',
            'buka' => '06.00',
            'tutup' => '22.00',
            'category' => 'futsal',
            'price' => '50.000',
        ]);
        $eqt = Booking::create([
            'court_name' => "d'Groove Sport and Wellness Center",
            'location' => 'Jl. Soekarno Hatta No.27, Cibuntu, Kec. Bandung Kulon, Kota Bandung, Jawa Barat 40212',
            'buka' => '06.00',
            'tutup' => '22.00',
            'category' => 'basketball',
            'price' => '50.000',
        ]);

        //batununggal
        $eqt = Booking::create([
            'court_name' => "GOR Batununggal",
            'location' => 'Jl. Soekarno Hatta Jl. Batununggal Indah IX No.2, Mengger, Kec. Bandung Kidul, Kota Bandung, Jawa Barat 40266',
            'buka' => '07.00',
            'tutup' => '18.00',
            'category' => 'badminton',
            'price' => '50.000',
        ]);
        $eqt = Booking::create([
            'court_name' => "GOR Batununggal",
            'location' => 'Jl. Soekarno Hatta Jl. Batununggal Indah IX No.2, Mengger, Kec. Bandung Kidul, Kota Bandung, Jawa Barat 40266',
            'buka' => '07.00',
            'tutup' => '18.00',
            'category' => 'ping_pong',
            'price' => '50.000',
        ]);
        $eqt = Booking::create([
            'court_name' => "GOR Batununggal",
            'location' => 'Jl. Soekarno Hatta Jl. Batununggal Indah IX No.2, Mengger, Kec. Bandung Kidul, Kota Bandung, Jawa Barat 40266',
            'buka' => '07.00',
            'tutup' => '18.00',
            'category' => 'basketball',
            'price' => '50.000',
        ]);
        $eqt = Booking::create([
            'court_name' => "GOR Batununggal",
            'location' => 'Jl. Soekarno Hatta Jl. Batununggal Indah IX No.2, Mengger, Kec. Bandung Kidul, Kota Bandung, Jawa Barat 40266',
            'buka' => '07.00',
            'tutup' => '18.00',
            'category' => 'futsal',
            'price' => '50.000',
        ]);
    }
}
